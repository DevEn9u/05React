import React from 'react';

export default function InfoList() {
  return (
    <>
      <ul className="info_list">
        <li>albumId : </li>
        <li>id : </li>
        <li>title : </li>
        <li>url : </li>
        <li>thumbnailUrl : </li>
      </ul>
    </>
  );
}
